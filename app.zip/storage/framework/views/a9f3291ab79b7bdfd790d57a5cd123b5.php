<?php if (isset($component)) { $__componentOriginal5ccb985d839473449772afd116d790ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ccb985d839473449772afd116d790ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.store','data' => ['title' => $seo['title'],'seo' => $seo,'trackingContext' => $trackingContext]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo['title']),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo),'tracking-context' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trackingContext)]); ?>
    <div class="space-y-8">
        <div class="paper-card p-6 md:p-8 bg-gradient-to-r from-[#f2eee3] to-[#e4dec9] flex flex-col md:flex-row justify-between items-center gap-4">
            <div><h1 class="text-3xl font-black text-gray-900">Product Catalog</h1><p class="text-sm text-gray-600 mt-1">Explore our complete collection of curated paper-crafted goods.</p></div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <aside class="space-y-6">
                <?php if($selectedCategory): ?>
                    <div class="md:hidden paper-card p-4 flex justify-between items-center">
                        <h2 class="font-bold text-gray-900">Filters</h2>
                        <button type="button" data-category-filter-toggle aria-controls="category-filter-panel" aria-expanded="false" class="text-sm font-bold text-brandRed hover:underline">Show</button>
                    </div>
                <?php endif; ?>
                <form id="category-filter-panel" method="GET" action="<?php echo e($selectedCategory ? route('categories.show', ['category' => $selectedCategory->slug]) : route('products.index')); ?>" class="paper-card p-6 space-y-6 <?php echo e($selectedCategory ? 'hidden md:block' : ''); ?>">
                    <div class="<?php echo e($selectedCategory ? 'hidden md:flex' : 'flex'); ?> justify-between items-center border-b border-gray-200 pb-4"><h2 class="font-bold text-gray-900">Filters</h2><a href="<?php echo e(route('products.index')); ?>" class="text-xs text-brandRed font-bold hover:underline">Reset All</a></div>
                    <div class="space-y-3"><h3 class="text-xs font-bold text-gray-700 uppercase tracking-wider">Categories</h3><div class="space-y-2 text-sm"><a href="<?php echo e(route('products.index')); ?>" class="block <?php echo e($selectedCategory ? 'text-gray-700' : 'font-bold text-brandRed'); ?> hover:text-brandRed">All products</a><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('categories.show', ['category' => $category->slug])); ?>" class="block <?php echo e($selectedCategory?->id === $category->id ? 'font-bold text-brandRed' : 'text-gray-700'); ?> hover:text-brandRed"><?php echo e($category->name); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div>
                    <?php ($selectedMaxPrice = (int) ($filters['max_price'] ?? $priceRangeMax)); ?>
                    <div class="space-y-3 pt-4 border-t border-gray-200"><label for="max_price" class="flex justify-between text-xs font-bold text-gray-700 uppercase tracking-wider"><span>Max Price</span><span class="text-brandRed"><?php echo e(\App\Support\Money::display($selectedMaxPrice * 100)); ?></span></label><input id="max_price" type="range" name="max_price" min="0" max="<?php echo e($priceRangeMax); ?>" step="10" value="<?php echo e(min($selectedMaxPrice, $priceRangeMax)); ?>" class="w-full accent-brandRed cursor-pointer"></div>
                    <div class="space-y-3 pt-4 border-t border-gray-200"><label for="filter_q" class="text-xs font-bold text-gray-700 uppercase tracking-wider">Keyword</label><input id="filter_q" type="search" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" placeholder="Search catalog" class="paper-input py-2 px-3 text-xs w-full"></div>
                    <div class="space-y-3 pt-4 border-t border-gray-200"><label for="sort" class="text-xs font-bold text-gray-700 uppercase tracking-wider">Sort By</label><select id="sort" name="sort" class="paper-input py-2 px-3 text-xs w-full"><option value="featured" <?php if(($filters['sort'] ?? 'featured') === 'featured'): echo 'selected'; endif; ?>>Featured / Default</option><option value="price_asc" <?php if(($filters['sort'] ?? '') === 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option><option value="price_desc" <?php if(($filters['sort'] ?? '') === 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option><option value="rating" <?php if(($filters['sort'] ?? '') === 'rating'): echo 'selected'; endif; ?>>Highest Rated</option></select></div>
                    <button class="paper-btn w-full py-3 bg-brandRed text-white text-xs font-bold rounded-xl hover:bg-brandRedHover">Apply Filters</button>
                </form>
            </aside>
            <div class="lg:col-span-3">
                <?php if($products->isEmpty()): ?>
                    <div class="paper-card p-12 text-center text-gray-500"><i class="fas fa-search text-4xl mb-3 text-gray-400" aria-hidden="true"></i><h2 class="font-bold text-lg text-gray-800">No products found</h2><p class="text-sm mt-1">Try adjusting your filters or search query.</p><a href="<?php echo e(route('products.index')); ?>" class="inline-block mt-4 paper-btn px-6 py-2 bg-brandRed text-white text-xs font-semibold rounded-xl">Reset Filters</a></div>
                <?php else: ?>
                    <div id="catalog-product-list" data-tracking-results="<?php echo e($products->total()); ?>" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6"><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product,'position' => $loop->iteration]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'position' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($loop->iteration)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                    <div class="mt-8"><?php echo e($products->links()); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if($selectedCategory): ?>
        <script src="<?php echo e(asset('js/category-filter.js')); ?>?v=<?php echo e(filemtime(public_path('js/category-filter.js'))); ?>" defer></script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $attributes = $__attributesOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__attributesOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $component = $__componentOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__componentOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views/store/products/index.blade.php ENDPATH**/ ?>