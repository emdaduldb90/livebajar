<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Orders']); ?>
    <form method="GET" class="paper-card p-4 mb-6 flex flex-col md:flex-row gap-3"><input name="q" value="<?php echo e($filters['q'] ?? ''); ?>" type="search" placeholder="Order number or customer email" class="paper-input px-4 py-2.5 text-sm flex-1"><select name="status" class="paper-input px-4 py-2.5 text-sm md:w-52"><option value="">All statuses</option><?php $__currentLoopData = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><button class="paper-btn bg-gray-900 text-white px-5 py-2.5 text-sm font-bold">Filter</button></form>
    <div class="paper-card p-3 md:p-5 overflow-x-auto"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Payment</th><th>Total</th><th>Order Status</th><th>Date</th><th></th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td class="font-black text-gray-900"><?php echo e($order->order_number); ?></td><td><p class="font-semibold text-gray-800"><?php echo e($order->customer_name); ?></p><p class="text-xs text-gray-500"><?php echo e($order->customer_email); ?></p></td><td><p class="capitalize font-semibold"><?php echo e($order->payment_method); ?></p><p class="text-xs text-gray-500 capitalize"><?php echo e($order->payment_status); ?></p></td><td class="font-black"><?php echo e(\App\Support\Money::display($order->total_cents)); ?></td><td><span class="admin-status admin-status-<?php echo e($order->status); ?>"><?php echo e(ucfirst($order->status)); ?></span></td><td class="text-sm text-gray-600 whitespace-nowrap"><?php echo e($order->created_at->format('d M Y')); ?></td><td><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="text-sm font-bold text-brandRed hover:underline">Manage</a></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="text-center text-gray-500 py-10">No orders found.</td></tr><?php endif; ?></tbody></table></div><div class="mt-6"><?php echo e($orders->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>