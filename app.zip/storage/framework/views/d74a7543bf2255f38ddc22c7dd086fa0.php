<?php if (isset($component)) { $__componentOriginal5ccb985d839473449772afd116d790ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ccb985d839473449772afd116d790ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.store','data' => ['title' => 'Shopping Cart | Live Bajar','trackingContext' => $trackingContext]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Shopping Cart | Live Bajar','tracking-context' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trackingContext)]); ?>
    <?php if($summary['items']->isEmpty()): ?>
        <div class="paper-card p-12 text-center max-w-xl mx-auto my-12 space-y-6"><div class="w-24 h-24 paper-card-inset rounded-full flex items-center justify-center text-4xl text-gray-400 mx-auto"><i class="fas fa-shopping-cart" aria-hidden="true"></i></div><h1 class="text-2xl font-black text-gray-900">Your Shopping Cart is Empty</h1><p class="text-sm text-gray-600">Looks like you haven't added any paper-crafted products to your cart yet.</p><a href="<?php echo e(route('products.index')); ?>" class="paper-btn px-8 py-3.5 bg-brandRed text-white font-bold rounded-xl shadow-md hover:bg-brandRedHover inline-flex items-center gap-2"><span>Start Shopping</span><i class="fas fa-arrow-right" aria-hidden="true"></i></a></div>
    <?php else: ?>
        <div class="space-y-8">
            <h1 class="text-3xl font-black text-gray-900">Shopping Cart (<?php echo e($summary['items']->sum('quantity')); ?> items)</h1>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-2 space-y-4">
                    <?php $__currentLoopData = $summary['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($product = $item['product']); ?>
                        <div class="paper-card p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                            <div class="flex items-center gap-4 w-full sm:w-auto"><a href="<?php echo e(route('products.show', $product)); ?>" class="w-20 h-20 aspect-square paper-card-inset bg-white overflow-hidden flex-shrink-0"><img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" width="80" height="80" class="w-full h-full object-cover"></a><div><a href="<?php echo e(route('categories.show', ['category' => $product->category->slug])); ?>" class="text-[10px] font-bold text-gray-500 uppercase tracking-wider"><?php echo e($product->category->name); ?></a><a href="<?php echo e(route('products.show', $product)); ?>" class="block font-bold text-gray-800 text-sm hover:text-brandRed line-clamp-1"><?php echo e($product->name); ?></a><div class="text-brandRed font-black text-base mt-1"><?php echo e(\App\Support\Money::display($product->price_cents)); ?></div></div></div>
                            <div class="flex items-center justify-between w-full sm:w-auto gap-6">
                                <form action="<?php echo e(route('cart.update', $product->id)); ?>" method="POST" class="flex items-center paper-input overflow-hidden"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><button name="quantity" value="<?php echo e($item['quantity'] - 1); ?>" class="px-3 py-1.5 hover:bg-black/5 font-bold text-gray-700" aria-label="Decrease quantity">-</button><span class="px-3 py-1.5 font-bold text-sm text-gray-800"><?php echo e($item['quantity']); ?></span><button name="quantity" value="<?php echo e($item['quantity'] + 1); ?>" class="px-3 py-1.5 hover:bg-black/5 font-bold text-gray-700" aria-label="Increase quantity">+</button></form>
                                <div class="text-right font-black text-gray-900 w-20"><?php echo e(\App\Support\Money::display($item['line_total_cents'])); ?></div>
                                <form action="<?php echo e(route('cart.destroy', $product->id)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-gray-400 hover:text-brandRed p-2 transition-colors" title="Remove item" aria-label="Remove <?php echo e($product->name); ?>"><i class="fas fa-trash-can text-sm" aria-hidden="true"></i></button></form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <aside class="space-y-6"><div class="paper-card p-6 space-y-6"><h2 class="font-bold text-gray-900 text-lg border-b border-gray-200 pb-4">Cart Summary</h2>
                    <div class="space-y-2"><label for="coupon" class="text-xs font-bold text-gray-700 uppercase tracking-wider">Coupon Code</label><form action="<?php echo e(route('cart.coupon')); ?>" method="POST" class="flex gap-2"><?php echo csrf_field(); ?><input id="coupon" name="code" type="text" value="<?php echo e($summary['coupon']?->code); ?>" placeholder="e.g. LIVE10" class="paper-input py-2 px-3 text-xs w-full"><button class="paper-btn px-4 py-2 bg-gray-900 text-white font-semibold text-xs rounded-xl">Apply</button></form><p class="text-[11px] text-gray-500">Try code <strong class="text-brandRed">LIVE10</strong> for 10% off!</p><?php if($summary['coupon']): ?><form action="<?php echo e(route('cart.coupon.destroy')); ?>" method="POST" class="text-right"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-xs text-brandRed font-bold hover:underline">Remove coupon</button></form><?php endif; ?></div>
                    <div class="space-y-3 pt-4 border-t border-gray-200 text-sm"><div class="flex justify-between text-gray-600"><span>Subtotal</span><span class="font-semibold text-gray-800"><?php echo e(\App\Support\Money::display($summary['subtotal_cents'])); ?></span></div><?php if($summary['discount_cents'] > 0): ?><div class="flex justify-between text-emerald-600 font-semibold"><span>Discount</span><span>-<?php echo e(\App\Support\Money::display($summary['discount_cents'])); ?></span></div><?php endif; ?><div class="flex justify-between text-gray-600"><span>Estimated Shipping</span><span class="font-semibold text-gray-800"><?php echo $summary['shipping_cents'] === 0 ? '<span class="text-emerald-600 uppercase font-bold text-xs">Free</span>' : \App\Support\Money::display($summary['shipping_cents']); ?></span></div><div class="flex justify-between text-lg font-black text-gray-900 pt-3 border-t border-gray-200"><span>Total</span><span class="text-brandRed"><?php echo e(\App\Support\Money::display($summary['total_cents'])); ?></span></div></div>
                    <a href="<?php echo e(route('checkout.create')); ?>" class="paper-btn w-full py-4 bg-brandRed text-white font-bold rounded-xl shadow-lg hover:bg-brandRedHover flex items-center justify-center gap-2"><span>Proceed to Checkout</span><i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                </div></aside>
            </div>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $attributes = $__attributesOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__attributesOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $component = $__componentOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__componentOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\cart\index.blade.php ENDPATH**/ ?>