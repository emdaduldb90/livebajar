<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Categories']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Categories']); ?>
    <div class="flex flex-col sm:flex-row gap-4 justify-between mb-6"><div><p class="text-sm text-gray-600">Organize the storefront catalog.</p></div><a href="<?php echo e(route('admin.categories.create')); ?>" class="paper-btn bg-brandRed text-white px-5 py-3 font-bold text-sm rounded-xl hover:bg-brandRedHover inline-flex items-center justify-center gap-2"><i class="fas fa-plus" aria-hidden="true"></i>Add Category</a></div>
    <div class="paper-card p-3 md:p-5 overflow-x-auto"><table class="admin-table"><thead><tr><th>Name</th><th>Slug</th><th>Products</th><th>Status</th><th>Homepage</th><th class="text-right">Actions</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td class="font-bold text-gray-900"><?php echo e($category->name); ?></td><td><code class="text-xs bg-gray-100 py-1 px-2 rounded"><?php echo e($category->slug); ?></code></td><td><?php echo e($category->products_count); ?></td><td><span class="admin-status <?php echo e($category->is_active ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($category->is_active ? 'Active' : 'Hidden'); ?></span></td><td><span class="admin-status <?php echo e($category->show_on_homepage ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($category->show_on_homepage ? 'Shown' : 'Hidden'); ?></span></td><td><div class="flex justify-end gap-3"><a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="text-sm font-bold text-brandRed hover:underline">Edit</a><form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" onsubmit="return confirm('Delete this empty category?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-sm font-bold text-gray-500 hover:text-brandRed">Delete</button></form></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="text-center text-gray-500 py-10">No categories found.</td></tr><?php endif; ?></tbody></table></div><div class="mt-6"><?php echo e($categories->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\categories\index.blade.php ENDPATH**/ ?>