<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Coupons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Coupons']); ?>
    <div class="flex justify-between items-center mb-6"><p class="text-sm text-gray-600">Create discounts for customer orders.</p><a href="<?php echo e(route('admin.coupons.create')); ?>" class="paper-btn bg-brandRed text-white px-5 py-3 font-bold text-sm rounded-xl hover:bg-brandRedHover inline-flex items-center gap-2"><i class="fas fa-plus" aria-hidden="true"></i>Add Coupon</a></div>
    <div class="paper-card p-3 md:p-5 overflow-x-auto"><table class="admin-table"><thead><tr><th>Code</th><th>Discount</th><th>Minimum</th><th>Usage</th><th>Validity</th><th>Status</th><th class="text-right">Actions</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><code class="font-black text-brandRed"><?php echo e($coupon->code); ?></code></td><td><?php echo e($coupon->discount_type === 'percentage' ? $coupon->discount_value.'%' : '$'.number_format($coupon->discount_value, 2)); ?></td><td>$<?php echo e(number_format($coupon->minimum_order_amount, 2)); ?></td><td><?php echo e(number_format($coupon->used_count)); ?><?php if($coupon->usage_limit): ?> / <?php echo e(number_format($coupon->usage_limit)); ?><?php endif; ?></td><td class="text-xs text-gray-600"><div><?php echo e($coupon->starts_at?->format('d M Y') ?? 'Starts now'); ?></div><div><?php echo e($coupon->expires_at?->format('d M Y') ?? 'No expiry'); ?></div></td><td><span class="admin-status <?php echo e($coupon->is_active ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($coupon->is_active ? 'Active' : 'Disabled'); ?></span></td><td><div class="flex justify-end gap-3"><a href="<?php echo e(route('admin.coupons.edit', $coupon)); ?>" class="text-sm font-bold text-brandRed hover:underline">Edit</a><form action="<?php echo e(route('admin.coupons.destroy', $coupon)); ?>" method="POST" onsubmit="return confirm('Delete this coupon?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-sm font-bold text-gray-500 hover:text-brandRed">Delete</button></form></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="text-center text-gray-500 py-10">No coupons found.</td></tr><?php endif; ?></tbody></table></div><div class="mt-6"><?php echo e($coupons->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\coupons\index.blade.php ENDPATH**/ ?>