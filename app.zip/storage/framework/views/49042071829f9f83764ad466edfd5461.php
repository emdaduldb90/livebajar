<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Account Security']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Account Security']); ?>
    <div class="max-w-2xl">
        <section class="paper-card p-6 md:p-7"><div class="flex gap-4 pb-6 mb-6 border-b border-gray-200"><div class="w-12 h-12 rounded-xl bg-brandRed/10 text-brandRed flex items-center justify-center text-xl"><i class="fas fa-user-shield" aria-hidden="true"></i></div><div><h2 class="font-black text-gray-900 text-lg">Administrator account</h2><p class="text-sm text-gray-600"><?php echo e(auth()->user()->email); ?></p></div></div><h3 class="font-black text-gray-900 text-lg">Change password</h3><p class="text-sm text-gray-600 mt-1 mb-6">Use at least 12 characters with uppercase, lowercase, number, and symbol.</p><form action="<?php echo e(route('admin.account.password')); ?>" method="POST" class="space-y-5"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><div><label for="current_password" class="admin-label">Current Password *</label><input id="current_password" name="current_password" type="password" required autocomplete="current-password" class="paper-input admin-input"></div><div><label for="password" class="admin-label">New Password *</label><input id="password" name="password" type="password" required autocomplete="new-password" class="paper-input admin-input"></div><div><label for="password_confirmation" class="admin-label">Confirm New Password *</label><input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password" class="paper-input admin-input"></div><button class="paper-btn bg-brandRed text-white px-5 py-3 text-sm font-bold hover:bg-brandRedHover">Update Password</button></form></section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\account\edit.blade.php ENDPATH**/ ?>