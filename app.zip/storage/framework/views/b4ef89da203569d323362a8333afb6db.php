<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Facebook Commerce Data File']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Facebook Commerce Data File']); ?>
    <div class="max-w-4xl space-y-6">
        <section class="paper-card p-5 md:p-6"><div class="flex flex-col md:flex-row md:items-center md:justify-between gap-5"><div><h2 class="font-black text-gray-900 text-lg">Facebook Product Catalog Feed</h2><p class="text-sm text-gray-600 mt-1">Generates an XML data file using all active products, current price, stock status, product image, category and brand.</p></div><form action="<?php echo e(route('admin.seo.facebook-commerce.update')); ?>" method="POST"><?php echo csrf_field(); ?><button class="paper-btn bg-brandRed text-white px-5 py-3 text-sm font-bold hover:bg-brandRedHover inline-flex items-center gap-2"><i class="fas fa-rotate" aria-hidden="true"></i>Update File</button></form></div></section>
        <section class="paper-card p-5 md:p-6"><h2 class="font-black text-gray-900 text-lg mb-4">Current File</h2><dl class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm"><div><dt class="text-xs font-bold uppercase tracking-wider text-gray-500">File</dt><dd class="font-semibold text-gray-800 mt-1"><?php echo e($file['name']); ?></dd></div><div><dt class="text-xs font-bold uppercase tracking-wider text-gray-500">Status</dt><dd class="font-semibold mt-1 <?php echo e($file['exists'] ? 'text-emerald-700' : 'text-amber-700'); ?>"><?php echo e($file['exists'] ? 'Generated' : 'Not generated yet'); ?></dd></div><?php if($file['exists']): ?><div><dt class="text-xs font-bold uppercase tracking-wider text-gray-500">Last Updated</dt><dd class="text-gray-800 mt-1"><?php echo e($file['updated_at']->format('d M Y, h:i A')); ?></dd></div><div><dt class="text-xs font-bold uppercase tracking-wider text-gray-500">File Size</dt><dd class="text-gray-800 mt-1"><?php echo e(number_format($file['size'] / 1024, 1)); ?> KB</dd></div><?php endif; ?></dl><div class="mt-5 pt-5 border-t border-gray-200"><p class="text-xs font-bold uppercase tracking-wider text-gray-500">Feed URL</p><a href="<?php echo e($file['url']); ?>" target="_blank" rel="noopener" class="text-sm font-bold text-brandRed break-all hover:underline"><?php echo e($file['url']); ?></a></div></section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\seo\facebook-commerce.blade.php ENDPATH**/ ?>