<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Pages']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Pages']); ?><div class="flex justify-end mb-5"><a href="<?php echo e(route('admin.pages.create')); ?>" class="paper-btn bg-brandRed text-white px-5 py-2.5 text-sm font-bold hover:bg-brandRedHover"><i class="fas fa-plus mr-1" aria-hidden="true"></i>Add Page</a></div><div class="paper-card p-3 md:p-5 overflow-x-auto"><table class="admin-table"><thead><tr><th>Page</th><th>URL</th><th>Status</th><th class="text-right">Actions</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><p class="font-bold text-gray-900"><?php echo e($page->title); ?></p><p class="text-xs text-gray-500"><?php echo e($page->excerpt); ?></p></td><td><a href="<?php echo e(route('pages.show', $page)); ?>" target="_blank" class="text-brandRed text-xs font-bold hover:underline">/<?php echo e($page->slug); ?></a></td><td><span class="admin-status <?php echo e($page->is_published ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($page->is_published ? 'Published' : 'Draft'); ?></span></td><td><div class="flex justify-end gap-3"><a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="text-sm font-bold text-brandRed hover:underline">Edit</a><form action="<?php echo e(route('admin.pages.destroy', $page)); ?>" method="POST" onsubmit="return confirm('Delete this page?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-sm font-bold text-gray-500 hover:text-brandRed">Delete</button></form></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="py-10 text-center text-gray-500">No pages found.</td></tr><?php endif; ?></tbody></table></div><div class="mt-6"><?php echo e($pages->links()); ?></div> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\pages\index.blade.php ENDPATH**/ ?>