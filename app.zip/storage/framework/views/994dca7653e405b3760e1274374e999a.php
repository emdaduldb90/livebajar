<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product', 'position' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product', 'position' => null]); ?>
<?php foreach (array_filter((['product', 'position' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $productTracking = app(\App\Services\Tracking\EcommerceTrackingService::class)->product($product, 1, $position);
    $productTrackingEncoded = app(\App\Services\Tracking\TrackingContext::class)->encode($productTracking);
    $productCategories = $product->categories->isNotEmpty() ? $product->categories : collect([$product->category]);
?>

<div class="paper-card p-4 flex flex-col justify-between group hover:-translate-y-1 transition-all">
    <div>
        <a href="<?php echo e(route('products.show', $product)); ?>" data-tracking-ecommerce="Product Clicked" data-tracking-properties="<?php echo e($productTrackingEncoded); ?>" class="relative block aspect-square paper-card-inset mb-4 overflow-hidden bg-white cursor-pointer">
            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->mainImageAsset?->alt_text ?: $product->name); ?>" width="600" height="600" loading="lazy" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
            <?php if($product->badge): ?><span class="absolute top-3 left-3 bg-brandRed text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow"><?php echo e($product->badge); ?></span><?php endif; ?>
        </a>
        <div class="flex flex-wrap gap-x-2 gap-y-1">
            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category): ?>
                    <a href="<?php echo e(route('categories.show', ['category' => $category->slug])); ?>" class="text-[11px] font-semibold text-gray-500 uppercase tracking-wider hover:text-brandRed"><?php echo e($category->name); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="<?php echo e(route('products.show', $product)); ?>" data-tracking-ecommerce="Product Clicked" data-tracking-properties="<?php echo e($productTrackingEncoded); ?>" class="block font-bold text-gray-800 text-sm mt-1 line-clamp-1 hover:text-brandRed"><?php echo e($product->name); ?></a>
        <div class="flex items-center gap-1.5 mt-2 text-amber-500 text-xs"><i class="fas fa-star" aria-hidden="true"></i><span class="font-bold text-gray-700"><?php echo e(number_format($product->rating, 1)); ?></span><span class="text-gray-400">(<?php echo e($product->reviews_count); ?>)</span></div>
    </div>
    <div class="mt-4 pt-3 border-t border-gray-200/60 flex items-center justify-between">
        <div><span class="text-lg font-black text-gray-900"><?php echo e(\App\Support\Money::display($product->price_cents)); ?></span><?php if($product->compare_at_price): ?><span class="text-xs text-gray-400 line-through ml-1.5"><?php echo e(\App\Support\Money::display($product->compare_at_price_cents)); ?></span><?php endif; ?></div>
        <form action="<?php echo e(route('cart.store', $product->id)); ?>" method="POST"><?php echo csrf_field(); ?><input type="hidden" name="quantity" value="1"><button class="paper-btn p-2.5 bg-brandRed text-white hover:bg-brandRedHover rounded-xl shadow-sm" title="Add to Cart" aria-label="Add <?php echo e($product->name); ?> to cart"><i class="fas fa-cart-plus text-sm" aria-hidden="true"></i></button></form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\components\product-card.blade.php ENDPATH**/ ?>