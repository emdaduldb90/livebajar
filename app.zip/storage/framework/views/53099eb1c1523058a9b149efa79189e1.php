<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Store Overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Store Overview']); ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
        <div class="admin-stat"><div><p class="admin-stat-label">Products</p><p class="admin-stat-number"><?php echo e(number_format($stats['products'])); ?></p></div><span class="admin-stat-icon bg-blue-50 text-blue-600"><i class="fas fa-box" aria-hidden="true"></i></span></div>
        <div class="admin-stat"><div><p class="admin-stat-label">Pending Orders</p><p class="admin-stat-number"><?php echo e(number_format($stats['pending_orders'])); ?></p></div><span class="admin-stat-icon bg-amber-50 text-amber-600"><i class="fas fa-clock" aria-hidden="true"></i></span></div>
        <div class="admin-stat"><div><p class="admin-stat-label">Low Stock</p><p class="admin-stat-number"><?php echo e(number_format($stats['low_stock'])); ?></p></div><span class="admin-stat-icon bg-red-50 text-brandRed"><i class="fas fa-triangle-exclamation" aria-hidden="true"></i></span></div>
        <div class="admin-stat"><div><p class="admin-stat-label">Today’s Sales</p><p class="admin-stat-number"><?php echo e(\App\Support\Money::display((int) round($stats['today_sales'] * 100))); ?></p></div><span class="admin-stat-icon bg-emerald-50 text-emerald-600"><i class="fas fa-chart-line" aria-hidden="true"></i></span></div>
    </div>

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <section class="paper-card p-5 md:p-6 xl:col-span-2">
            <div class="flex justify-between items-center mb-5"><div><h2 class="font-black text-gray-900 text-lg">Recent Orders</h2><p class="text-sm text-gray-500">Latest customer orders</p></div><a href="<?php echo e(route('admin.orders.index')); ?>" class="text-sm font-bold text-brandRed hover:underline">View all &rarr;</a></div>
            <?php if($recentOrders->isEmpty()): ?><p class="text-sm text-gray-500 py-8 text-center">No orders yet.</p><?php else: ?>
                <div class="overflow-x-auto"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody><?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td class="font-bold text-gray-900"><?php echo e($order->order_number); ?></td><td><p class="font-semibold text-gray-800"><?php echo e($order->customer_name); ?></p><p class="text-xs text-gray-500"><?php echo e($order->customer_email); ?></p></td><td class="font-bold"><?php echo e(\App\Support\Money::display($order->total_cents)); ?></td><td><span class="admin-status admin-status-<?php echo e($order->status); ?>"><?php echo e(ucfirst($order->status)); ?></span></td><td><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="text-brandRed hover:underline text-sm font-bold">Open</a></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></div>
            <?php endif; ?>
        </section>
        <section class="paper-card p-5 md:p-6">
            <div class="flex justify-between items-center mb-5"><div><h2 class="font-black text-gray-900 text-lg">Low Stock Alert</h2><p class="text-sm text-gray-500">5 or fewer units left</p></div><a href="<?php echo e(route('admin.products.index')); ?>" class="text-sm font-bold text-brandRed hover:underline">Products</a></div>
            <?php if($lowStockProducts->isEmpty()): ?><div class="py-10 text-center text-emerald-700"><i class="fas fa-circle-check text-3xl mb-3" aria-hidden="true"></i><p class="font-bold">Stock levels look good.</p></div><?php else: ?>
                <ul class="space-y-3"><?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="paper-card-inset p-3 flex items-center justify-between gap-3"><div class="min-w-0"><p class="font-bold text-sm text-gray-800 truncate"><?php echo e($product->name); ?></p><p class="text-xs text-gray-500"><?php echo e($product->slug); ?></p></div><span class="bg-red-50 text-brandRed text-xs font-black rounded-full px-2.5 py-1 whitespace-nowrap"><?php echo e($product->stock_quantity); ?> left</span></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>