<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Products']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Products']); ?>
    <div class="flex flex-col lg:flex-row gap-4 justify-between mb-6">
        <form method="GET" class="flex gap-2 w-full lg:max-w-md">
            <input name="q" value="<?php echo e($search); ?>" type="search" placeholder="Search product name..." class="paper-input px-4 py-2.5 text-sm flex-1">
            <button class="paper-btn px-4 py-2.5 text-sm font-bold">Search</button>
        </form>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="paper-btn bg-brandRed text-white px-5 py-3 font-bold text-sm rounded-xl hover:bg-brandRedHover inline-flex items-center justify-center gap-2"><i class="fas fa-plus" aria-hidden="true"></i>Add Product</a>
    </div>
    <div class="paper-card p-3 md:p-5 overflow-x-auto">
        <table class="admin-table">
            <thead><tr><th>Product</th><th>Categories / Brand</th><th>Price</th><th>Stock</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><div class="flex items-center gap-3 min-w-[240px]"><img src="<?php echo e($product->image_url); ?>" alt="" width="42" height="42" class="w-11 h-11 rounded-lg object-cover bg-white"><div><p class="font-bold text-gray-900"><?php echo e($product->name); ?></p><p class="text-xs text-gray-500"><?php echo e($product->sku); ?></p></div></div></td>
                        <td><p><?php echo e($product->categories->pluck('name')->join(', ') ?: $product->category->name); ?></p><p class="text-xs text-gray-500"><?php echo e($product->brand?->name ?: 'No brand'); ?></p></td>
                        <td class="font-bold"><?php echo e(\App\Support\Money::display($product->price_cents)); ?></td>
                        <td><span class="<?php echo e($product->stock_quantity <= 5 ? 'text-brandRed font-black' : 'text-gray-700'); ?>"><?php echo e($product->stock_quantity); ?></span></td>
                        <td><span class="admin-status <?php echo e($product->is_active ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($product->is_active ? 'Active' : 'Archived'); ?></span></td>
                        <td><div class="flex justify-end gap-3"><a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="text-sm font-bold text-brandRed hover:underline">Edit</a><form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Delete this product? Existing orders will keep their item history.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-sm font-bold text-gray-500 hover:text-brandRed">Delete</button></form></div></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-center text-gray-500 py-10">No products found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-6"><?php echo e($products->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views/admin/products/index.blade.php ENDPATH**/ ?>