<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['heading' => 'Brands']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Brands']); ?>
    <div class="flex justify-end mb-6"><a href="<?php echo e(route('admin.brands.create')); ?>" class="paper-btn bg-brandRed text-white px-5 py-3 font-bold text-sm rounded-xl hover:bg-brandRedHover inline-flex items-center gap-2"><i class="fas fa-plus" aria-hidden="true"></i>Add Brand</a></div>
    <div class="paper-card p-3 md:p-5 overflow-x-auto"><table class="admin-table"><thead><tr><th>Brand</th><th>Slug</th><th>Products</th><th>Status</th><th class="text-right">Actions</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td class="font-bold text-gray-900"><?php echo e($brand->name); ?></td><td><code class="text-xs bg-gray-100 py-1 px-2 rounded"><?php echo e($brand->slug); ?></code></td><td><?php echo e($brand->products_count); ?></td><td><span class="admin-status <?php echo e($brand->is_active ? 'admin-status-delivered' : 'admin-status-cancelled'); ?>"><?php echo e($brand->is_active ? 'Active' : 'Hidden'); ?></span></td><td><div class="flex justify-end gap-3"><a href="<?php echo e(route('admin.brands.edit', $brand)); ?>" class="text-sm font-bold text-brandRed hover:underline">Edit</a><?php if($brand->products_count === 0): ?><form action="<?php echo e(route('admin.brands.destroy', $brand)); ?>" method="POST" onsubmit="return confirm('Delete this brand?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-sm font-bold text-gray-500 hover:text-brandRed">Delete</button></form><?php endif; ?></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="text-center text-gray-500 py-10">No brands yet. Add one to select it on products.</td></tr><?php endif; ?></tbody></table></div><div class="mt-6"><?php echo e($brands->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\admin\brands\index.blade.php ENDPATH**/ ?>