<?php if (isset($component)) { $__componentOriginal5ccb985d839473449772afd116d790ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ccb985d839473449772afd116d790ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.store','data' => ['title' => $seo['title'],'seo' => $seo]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo['title']),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo)]); ?><article class="paper-card max-w-4xl mx-auto p-7 sm:p-10"><nav class="text-xs text-gray-500 mb-6"><a href="<?php echo e(route('home')); ?>" class="hover:text-brandRed">Home</a><span class="px-2">/</span><span><?php echo e($page->title); ?></span></nav><h1 class="text-3xl font-black text-gray-900"><?php echo e($page->title); ?></h1><?php if($page->excerpt): ?><p class="mt-3 text-gray-600"><?php echo e($page->excerpt); ?></p><?php endif; ?><div class="mt-7 pt-7 border-t border-gray-200 text-sm leading-7 text-gray-700 whitespace-pre-line"><?php echo e($page->content); ?></div></article> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $attributes = $__attributesOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__attributesOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ccb985d839473449772afd116d790ad)): ?>
<?php $component = $__componentOriginal5ccb985d839473449772afd116d790ad; ?>
<?php unset($__componentOriginal5ccb985d839473449772afd116d790ad); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views\store\pages\show.blade.php ENDPATH**/ ?>