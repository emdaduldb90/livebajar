<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => 'Live Bajar - Ultimate Paper-Crafted Shopping Experience', 'trackingContext' => null, 'seo' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => 'Live Bajar - Ultimate Paper-Crafted Shopping Experience', 'trackingContext' => null, 'seo' => []]); ?>
<?php foreach (array_filter((['title' => 'Live Bajar - Ultimate Paper-Crafted Shopping Experience', 'trackingContext' => null, 'seo' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $pageTrackingEvents = is_array($trackingContext) && is_array($trackingContext['events'] ?? null) ? $trackingContext['events'] : [];
    $flashedTrackingEvents = app(\App\Services\Tracking\TrackingEventStore::class)->pull();
    $trackingPayload = ['events' => array_merge($flashedTrackingEvents, $pageTrackingEvents)];
    $trackingPayloadEncoded = app(\App\Services\Tracking\TrackingContext::class)->encode($trackingPayload);
    $trackingIntelligenceConfig = app(\App\Services\Tracking\TrackingSettingsService::class)->publicConfig();
    $trackingEnabled = (bool) config('tracking.enabled') && (app()->environment('production') || (bool) config('tracking.allow_non_production'));
    $directBrowserTracking = ! $trackingIntelligenceConfig['test_mode'] && (
        $trackingIntelligenceConfig['meta']['browser_enabled']
        || $trackingIntelligenceConfig['tiktok']['browser_enabled']
        || $trackingIntelligenceConfig['ga4']['browser_enabled']
        || $trackingIntelligenceConfig['google_ads']['browser_enabled']
    );
    $trackingUserAgent = (string) request()->userAgent();
    $trackingExcluded = (auth()->check() && (bool) auth()->user()?->is_admin)
        || preg_match('/bot|crawler|spider|slurp|preview|headless/i', $trackingUserAgent) === 1
        || (! app()->environment('production') && ! (bool) config('tracking.allow_non_production'));
    $trackingConsentNeeded = ! $trackingExcluded && (((bool) config('tracking.require_consent') && $trackingEnabled)
        || ($trackingIntelligenceConfig['require_consent'] && ($trackingIntelligenceConfig['collection_enabled'] || $directBrowserTracking)));
    $trackingIntelligenceEncoded = app(\App\Services\Tracking\TrackingContext::class)->encode($trackingIntelligenceConfig + ['skip_tracking' => $trackingExcluded]);
    $headerMenu = $siteSettings['header_menu'] ?? [['label' => 'Home', 'url' => '/'], ['label' => 'Shop', 'url' => '/shop']];
    $footer = $siteSettings['footer'] ?? [];
    $footerQuickLinks = $footer['quick_links'] ?? [['label' => 'Home Page', 'url' => '/'], ['label' => 'Product Catalog & Filters', 'url' => '/shop'], ['label' => 'Shopping Cart', 'url' => '/cart'], ['label' => 'Checkout Securely', 'url' => '/checkout']];
    $footerCareLinks = $footer['care_links'] ?? [['label' => 'Fast delivery', 'url' => '/fast-delivery'], ['label' => 'Secure checkout', 'url' => '/secure-checkout'], ['label' => '30-day return policy', 'url' => '/30-day-return-policy'], ['label' => '24/7 dedicated support', 'url' => '/dedicated-support']];
    $serviceNotice = $siteSettings['service_notice'] ?? [];
    $heroImage = data_get($siteSettings, 'hero.image');
    $heroImageUrl = is_string($heroImage) && $heroImage !== '' && ! \Illuminate\Support\Str::startsWith($heroImage, ['http://', 'https://', '//']) ? asset('storage/'.ltrim($heroImage, '/')) : $heroImage;
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="index,follow">
    <title><?php echo e($title ?? 'Live Bajar - Ultimate Paper-Crafted Shopping Experience'); ?></title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="32x32">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>">
    <meta name="description" content="<?php echo e($seo['description'] ?? 'Shop curated products at Live Bajar.'); ?>">
    <?php if(! empty($seo['keywords'])): ?><meta name="keywords" content="<?php echo e($seo['keywords']); ?>"><?php endif; ?>
    <link rel="canonical" href="<?php echo e($seo['canonical'] ?? url()->current()); ?>">
    <?php if(request()->routeIs('home') && $heroImageUrl): ?><link rel="preload" as="image" href="<?php echo e($heroImageUrl); ?>" fetchpriority="high"><?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="<?php echo e(asset('css/store.css')); ?>?v=<?php echo e(filemtime(public_path('css/store.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tracking-consent.css')); ?>?v=<?php echo e(filemtime(public_path('css/tracking-consent.css'))); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>?v=<?php echo e(filemtime(public_path('vendor/fontawesome/css/all.min.css'))); ?>">
</head>
<body class="selection:bg-brandRed selection:text-white" data-tracking-enabled="<?php echo e($trackingEnabled ? '1' : '0'); ?>" data-tracking-debug="<?php echo e(config('tracking.debug') ? '1' : '0'); ?>" data-tracking-require-consent="<?php echo e(config('tracking.require_consent') ? '1' : '0'); ?>" data-tracking-excluded="<?php echo e($trackingExcluded ? '1' : '0'); ?>">
    <?php ($cartCount = app(\App\Services\CartService::class)->count()); ?>

    <header class="sticky top-0 z-40 backdrop-blur-md bg-[#f9f7f2]/80 border-b border-white/50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-3 cursor-pointer group" aria-label="Live Bajar home">
                <div class="relative w-12 h-12 paper-card flex items-center justify-center bg-white group-hover:scale-105 transition-transform overflow-hidden">
                    <svg viewBox="0 0 100 100" class="w-9 h-9" aria-hidden="true">
                        <path d="M15 30 H25 L35 65 H75 L85 35 H30" fill="none" stroke="#2d2d2d" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="40" cy="75" r="8" fill="#d62828"/>
                        <circle cx="70" cy="75" r="8" fill="#d62828"/>
                        <path d="M45 40 Q55 25 65 40 T85 40" fill="#d62828"/>
                    </svg>
                </div>
                <div>
                    <h1 class="text-2xl font-extrabold text-gray-900 logo-text tracking-tight flex items-center gap-1">Live <span class="text-brandRed">Bajar</span></h1>
                    <p class="text-[10px] uppercase tracking-widest text-gray-500 font-semibold">Paper Crafted Store</p>
                </div>
            </a>

            <form action="<?php echo e(route('products.index')); ?>" method="GET" class="hidden md:flex items-center flex-1 max-w-md mx-8">
                <label class="relative w-full">
                    <span class="sr-only">Search products</span>
                    <input type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search products, categories..." class="w-full py-2.5 pl-11 pr-4 paper-input text-sm text-gray-800 placeholder-gray-500">
                    <i class="fas fa-search absolute left-4 top-3.5 text-gray-400 text-sm" aria-hidden="true"></i>
                </label>
            </form>

            <nav class="flex items-center gap-4 sm:gap-6" aria-label="Primary navigation">
                <?php $__currentLoopData = $headerMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($menuItem['url'] ?? '/'); ?>" class="font-medium text-sm text-gray-700 hover:text-brandRed transition-colors hidden sm:block"><?php echo e($menuItem['label'] ?? 'Menu'); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('cart.index')); ?>" class="paper-btn p-3 relative flex items-center justify-center text-gray-700 hover:text-brandRed transition-all" title="View Cart" aria-label="View cart">
                    <i class="fas fa-shopping-cart text-lg" aria-hidden="true"></i>
                    <span class="absolute -top-1.5 -right-1.5 bg-brandRed text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-md"><?php echo e($cartCount); ?></span>
                </a>
                <details class="md:hidden relative">
                    <summary class="paper-btn p-3 text-gray-700 list-none cursor-pointer"><i class="fas fa-bars text-lg" aria-hidden="true"></i><span class="sr-only">Open menu</span></summary>
                    <div class="absolute right-0 top-14 w-72 paper-card p-4 flex flex-col gap-3 z-50">
                        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="relative w-full mb-2">
                            <label>
                                <span class="sr-only">Search products</span>
                                <input type="search" name="q" placeholder="Search products..." class="w-full py-2 pl-10 pr-4 paper-input text-sm text-gray-800">
                                <i class="fas fa-search absolute left-3.5 top-3 text-gray-400 text-xs" aria-hidden="true"></i>
                            </label>
                        </form>
                        <?php $__currentLoopData = $headerMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($menuItem['url'] ?? '/'); ?>" class="text-left py-2 px-3 font-medium text-gray-700 hover:bg-black/5 rounded-lg"><?php echo e($menuItem['label'] ?? 'Menu'); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('cart.index')); ?>" class="text-left py-2 px-3 font-medium text-gray-700 hover:bg-black/5 rounded-lg flex justify-between items-center"><span>Cart</span><span class="bg-brandRed text-white text-xs px-2 py-0.5 rounded-full"><?php echo e($cartCount); ?></span></a>
                    </div>
                </details>
            </nav>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-[calc(100vh-180px)]">
        <?php if(session('success')): ?>
            <div class="paper-card p-4 mb-6 text-sm font-semibold flex items-center gap-3 border-l-4 border-l-emerald-500 text-emerald-900" role="status"><i class="fas fa-check-circle text-emerald-600 text-lg" aria-hidden="true"></i><span><?php echo e(session('success')); ?></span></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="paper-card p-4 mb-6 text-sm font-semibold flex items-start gap-3 border-l-4 border-l-brandRed text-red-900" role="alert"><i class="fas fa-exclamation-circle text-brandRed text-lg mt-0.5" aria-hidden="true"></i><div><?php echo e($errors->first()); ?></div></div>
        <?php endif; ?>
        <?php echo e($slot); ?>

    </main>

    <aside id="livebajar-consent" class="lb-consent" data-enabled="<?php echo e($trackingConsentNeeded ? '1' : '0'); ?>" hidden aria-label="Privacy choices">
        <div class="lb-consent__content">
            <div class="lb-consent__copy"><strong class="lb-consent__title">Your privacy choices</strong><p class="lb-consent__description">Optional analytics and advertising measurement use browser events and, when configured, limited server events. Choose whether to allow this tracking. Essential store functions work either way.</p></div>
            <div class="lb-consent__actions">
                <button type="button" data-consent-choice="denied" class="lb-consent__button lb-consent__button--reject">Reject optional tracking</button>
                <button type="button" data-consent-choice="granted" class="lb-consent__button lb-consent__button--accept">Allow optional tracking</button>
            </div>
        </div>
    </aside>

    <div id="livebajar-tracking-context" hidden data-context="<?php echo e($trackingPayloadEncoded); ?>"></div>
    <div id="livebajar-tracking-config" hidden data-config="<?php echo e($trackingIntelligenceEncoded); ?>"></div>
    <script src="<?php echo e(asset('js/tracking-consent.js')); ?>?v=<?php echo e(filemtime(public_path('js/tracking-consent.js'))); ?>" defer></script>
    <script src="<?php echo e(asset('js/tracking.js')); ?>?v=<?php echo e(filemtime(public_path('js/tracking.js'))); ?>" defer></script>
    <script src="<?php echo e(asset('js/tracking-intelligence.js')); ?>?v=<?php echo e(filemtime(public_path('js/tracking-intelligence.js'))); ?>" defer></script>

    <footer class="paper-card rounded-none border-t border-white/60 bg-[#f4f0e6] mt-8 py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
                <div class="flex items-center gap-2 mb-4"><div class="w-8 h-8 paper-card flex items-center justify-center bg-white"><i class="fas fa-shopping-cart text-brandRed text-sm" aria-hidden="true"></i></div><h2 class="text-xl font-extrabold text-gray-900 logo-text">Live Bajar</h2></div>
                <p class="text-sm text-gray-600 leading-relaxed"><?php echo e($footer['about'] ?? 'Your ultimate paper-crafted online marketplace. Experience tactile shopping with modern elegance, high quality curated items, and fast delivery.'); ?></p>
            </div>
            <div>
                <h3 class="font-bold text-gray-800 mb-4 text-sm uppercase tracking-wider">Quick Links</h3>
                <ul class="space-y-2 text-sm text-gray-600"><?php $__currentLoopData = $footerQuickLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><a href="<?php echo e($link['url'] ?? '/'); ?>" class="hover:text-brandRed transition-colors"><?php echo e($link['label'] ?? 'Link'); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
            <div>
                <h3 class="font-bold text-gray-800 mb-4 text-sm uppercase tracking-wider">Customer Care</h3>
                <ul class="space-y-2 text-sm text-gray-600"><?php $__currentLoopData = $footerCareLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><a href="<?php echo e($link['url'] ?? '/'); ?>" class="hover:text-brandRed transition-colors"><?php echo e($link['label'] ?? 'Link'); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
            <div>
                <h3 class="font-bold text-gray-800 mb-4 text-sm uppercase tracking-wider"><?php echo e($footer['newsletter_title'] ?? 'Newsletter'); ?></h3>
                <p class="text-sm text-gray-600 mb-3"><?php echo e($footer['newsletter_text'] ?? 'Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.'); ?></p>
                <div class="flex gap-2"><input type="email" placeholder="Your email address" class="paper-input py-2 px-3 text-xs w-full" aria-label="Newsletter email"><a href="<?php echo e(route('products.index')); ?>" class="paper-btn px-4 py-2 bg-brandRed text-white text-xs font-semibold hover:bg-brandRedHover">Join</a></div>
            </div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 pt-6 border-t border-gray-300/60 text-center text-xs text-gray-500">&copy; <?php echo e(now()->year); ?> Live Bajar E-Commerce. All rights reserved. Designed with Paper-Cut Skeuomorphic Aesthetic.</div>
        <?php if($trackingConsentNeeded): ?><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-3 text-center text-xs"><button type="button" data-open-consent class="lb-privacy-choice">Privacy choices</button></div><?php endif; ?>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\livebajar\resources\views/components/layouts/store.blade.php ENDPATH**/ ?>